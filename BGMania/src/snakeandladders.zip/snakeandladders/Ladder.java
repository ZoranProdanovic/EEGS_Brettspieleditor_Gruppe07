/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package snakeandladders;

import classes.Cell;
import classes.SpecialField;

/**
 *
 * @author Adrian
 */
public class Ladder extends SpecialField {

    public Ladder(Cell activation_position, Cell resonse_position, int distance) {
        super(activation_position, resonse_position, distance);
    }
    
}
